The main differance between alpha 1.1 and beta 1.0 is the abillity to change Workspace.

alpha 1.0 & 1.1 have only 1 Workspace.
beta 1.0 has 4 Workspaces.

Also the key-comb for opening the Terminal is now "mod + T".