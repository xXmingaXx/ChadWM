#include <iostream>
#include <X11/Xlib.h>
#include <unistd.h>
#include <X11/keysym.h>
#include <cstdlib>
#include <vector>
#include "SXlib/SXlib.h"

//void-env is a extremly simple and fast desctop environment
//Version: alpha 1.0

using namespace std;

int main() {

    //vector<Window> Window_list;
    vec2 mouspos;

    //Verbindet zum X-Server
    Display* disp = XOpenDisplay(NULL);

    //#### Keybinds ###################################################

    //Mod = Alt | for Super(Windows) key as mod use Mod4Mask
    unsigned int mod = Mod1Mask;
    KeyCode esc = XKeysymToKeycode(disp, XK_Escape);

    KeyCode L = XKeysymToKeycode(disp, XK_Left);
    KeyCode R = XKeysymToKeycode(disp, XK_Right);

    KeyCode Full = XKeysymToKeycode(disp, XK_f);
    KeyCode X = XKeysymToKeycode(disp, XK_x);
    KeyCode T = XKeysymToKeycode(disp, XK_t);

    if (!disp){
        cerr << "[ERROR] Faild connecting to the X-Server!\n";
        return -1;
    }else{
        cout << "[OK] Connected to the X-Server!\n";
    }

    int screen = DefaultScreen(disp);

    int dpyw = DisplayWidth(disp, screen);
    int dpyh = DisplayHeight(disp, screen);

    Window root = DefaultRootWindow(disp);

    XSelectInput(disp, root, SubstructureRedirectMask | SubstructureNotifyMask | KeyPressMask | KeyReleaseMask | ButtonPressMask | ButtonReleaseMask);
    XSync(disp, False);
    XFlush(disp);

    XGrabKey(disp, esc, mod, root, True, GrabModeAsync, GrabModeAsync);

    XGrabKey(disp, L, mod, root, True, GrabModeAsync, GrabModeAsync);
    XGrabKey(disp, R, mod, root, True, GrabModeAsync, GrabModeAsync);

    XGrabKey(disp, Full, mod, root, True, GrabModeAsync, GrabModeAsync);
    XGrabKey(disp, X, mod, root, True, GrabModeAsync, GrabModeAsync);
    XGrabKey(disp, T, mod, root, True, GrabModeAsync, GrabModeAsync);

    //4 Workspaces each with 4 Windows max
    vector<vector<Window>> WSPACES  = {{}, {}, {}, {}};
    vector<bool> fxr = {0, 0, 0, 0};
    int WSindex = 0;

    Window dummyW;
    int dummyInt;

    XGrabButton(disp, AnyButton, mod, root, True, ButtonPressMask, GrabModeAsync, GrabModeAsync, None, None);

    XEvent event;
    XMapRequestEvent* e;
    XKeyEvent* ek;
    XDestroyWindowEvent* de;
    Window fwin;

    XWindowAttributes attr;

    Status s;


    while(true){
        XNextEvent(disp, &event);
        //Opening Windows
        if (event.type == MapRequest && WSPACES[WSindex].size() < 4){
            e = &event.xmaprequest;

            WSPACES[WSindex].push_back(e->window);

            XMapWindow(disp, e->window);
        }
        
        if (event.type == KeyPress){
            ek = &event.xkey;

            //Alt + 1 == kitty opens
            if (ek->keycode == T && (ek->state & mod)){
                system("kitty&");
                //system("xterm&");
            }

            //Alt + f == fullscreen
            else if (ek->keycode == Full && (ek->state & mod)){
                if (!fxr[WSindex]){
                    XGetInputFocus(disp, &fwin, &dummyInt);
                    fullscreen_window(disp, fwin, screen);
                    fxr[WSindex] = true;
                } else {fxr[WSindex] = false;}
                
            }

            else if (ek->keycode == X && (ek->state & mod)){
                XGetInputFocus(disp, &fwin, &dummyInt);
                for (int i=0; i<WSPACES[WSindex].size();i++){
                    if (fwin == WSPACES[WSindex][i]){
                        destroywin(disp, WSPACES[WSindex][i], root);
                        WSPACES[WSindex].erase(WSPACES[WSindex].begin()+i);
                        fxr[WSindex] = false;
                        break;
                    }
                }
            }

            else if (ek->keycode == L && (ek->state & mod) && WSindex > 0){
                WSindex--;
                UmapWS(disp, WSPACES[WSindex+1]);
                mapWS(disp, WSPACES[WSindex]);
            }

            else if (ek->keycode == R && (ek->state & mod) && WSindex < 3){
                WSindex++;
                UmapWS(disp, WSPACES[WSindex-1]);
                mapWS(disp, WSPACES[WSindex]);
            }

            //Alt + ESC == close WM
            else if (ek->keycode == esc && (ek->state & mod)){
                break;
            }
        }

        //check if windows are still alive
        if (event.type == DestroyNotify){
            de = &event.xdestroywindow;

            for (int i=0; i<WSPACES[WSindex].size();i++){
                if (de->window == WSPACES[WSindex][i]){
                    WSPACES[WSindex].erase(WSPACES[WSindex].begin()+i);
                    i--;
                    fxr[WSindex] == false;
                }
            }
        }

        

        //Manage Windows
        if (!fxr[WSindex]){
            if (WSPACES[WSindex].size() == 2){
                XMoveResizeWindow(disp, WSPACES[WSindex][0], 0, 0, dpyw/2, dpyh);
                XMoveResizeWindow(disp, WSPACES[WSindex][1], dpyw/2, 0, dpyw/2, dpyh);
            }

            if (WSPACES[WSindex].size() == 3){
                XMoveResizeWindow(disp, WSPACES[WSindex][0], 0, 0, dpyw/2, dpyh/2);
                XMoveResizeWindow(disp, WSPACES[WSindex][1], dpyw/2, 0, dpyw/2, dpyh/2);
                XMoveResizeWindow(disp, WSPACES[WSindex][2], 0, dpyh/2, dpyw, dpyh/2);
            }

            if (WSPACES[WSindex].size() == 4){
                XMoveResizeWindow(disp, WSPACES[WSindex][0], 0, 0, dpyw/2, dpyh/2);
                XMoveResizeWindow(disp, WSPACES[WSindex][1], dpyw/2, 0, dpyw/2, dpyh/2);
                XMoveResizeWindow(disp, WSPACES[WSindex][2], 0, dpyh/2, dpyw/2, dpyh/2);
                XMoveResizeWindow(disp, WSPACES[WSindex][3], dpyw/2, dpyh/2, dpyw/2, dpyh/2);
            }

            if (event.type == ButtonPress){
                mouspos.x = event.xbutton.x_root;
                mouspos.y = event.xbutton.y_root;

                if (WSPACES[WSindex].size() == 1){
                    focus_window(disp, WSPACES[WSindex][0]);
                }

                else if (WSPACES[WSindex].size() == 2){
                    if (mouspos.x < dpyw/2){
                        focus_window(disp, WSPACES[WSindex][0]);
                    } else{
                        focus_window(disp, WSPACES[WSindex][1]);
                    }
                }

                else if (WSPACES[WSindex].size() == 3){
                    if (mouspos.y > dpyh/2){
                        focus_window(disp, WSPACES[WSindex][2]);
                    } else if(mouspos.x < dpyw/2){
                        focus_window(disp, WSPACES[WSindex][0]);
                    } else {
                        focus_window(disp, WSPACES[WSindex][1]);
                    }
                }

                else if (WSPACES[WSindex].size() == 4){
                    if (mouspos.y < dpyh/2 && mouspos.x < dpyw/2){
                        focus_window(disp, WSPACES[WSindex][0]);
                    } else if (mouspos.y < dpyh/2 && mouspos.x > dpyw/2){
                        focus_window(disp, WSPACES[WSindex][1]);
                    } else if (mouspos.y > dpyh/2 && mouspos.x < dpyw/2){
                        focus_window(disp, WSPACES[WSindex][2]);
                    } else if (mouspos.y > dpyh/2 && mouspos.x > dpyw/2){
                        focus_window(disp, WSPACES[WSindex][3]);
                    }
                }

                XAllowEvents(disp, ReplayPointer, event.xbutton.time);


            }
        }

    }

    
    
    XCloseDisplay(disp);
    return 0;
}